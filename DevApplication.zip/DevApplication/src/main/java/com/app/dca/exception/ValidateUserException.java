package com.app.dca.exception;

public class ValidateUserException extends Exception {
	public ValidateUserException() {

	}
	public ValidateUserException(String message) {
		super(message);
	}
}
