package com.app.dca.entity;

public class SuccessMsg {
	private String msg;

	public SuccessMsg() {
		super();
	}
	
	public SuccessMsg(String msg) {
		super();
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
